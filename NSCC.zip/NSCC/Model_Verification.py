import netCDF4 as nc
import numpy as np
from sklearn.model_selection import train_test_split 
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import tensorflow as tf
from tensorflow.keras.layers import Input, Conv2D, UpSampling2D, Add, MaxPooling2D
from tensorflow.keras.models import Model, load_model
import matplotlib.pyplot as plt
import matplotlib.colors
import datetime as dt
import pandas as pd
import pickle

# Load the data for ten years
data = nc.Dataset('Analogue-Nowcasting-Model-Testing-Ground/ERA5_Data/ERA5_14_to_23_data.nc')

# Shape data
r = np.moveaxis(data['r'], 1, 0)
r = np.expand_dims(r[0],3)
u = np.moveaxis(data['u'], 1, -1)
v = np.moveaxis(data['v'], 1, -1)

# Preprocessing the data
# Normalize the data
scaler = StandardScaler()

u = scaler.fit_transform(u.reshape(-1, 1)).reshape(u.shape)
v = scaler.fit_transform(v.reshape(-1, 1)).reshape(v.shape)
r = scaler.fit_transform(r.reshape(-1, 1)).reshape(r.shape)

# Pad the data to get even dimensions
u = np.pad(u, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
v = np.pad(v, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
r = np.pad(r, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')

# Combine the parameters to form a single dataset
data_combined = np.concatenate((u, v, r), axis=-1)

# Load the model
autoencoder = load_model('Analogue-Nowcasting-Model-Testing-Ground/Saved Models/ResNet_00Z_Autoencoder_NSCC.keras')

# Compile the model
autoencoder.compile(optimizer='adam', loss='mse',metrics=['accuracy'])

loaded_history = pd.read_csv('Analogue-Nowcasting-Model-Testing-Ground/Saved Models/history_NSCC.csv')

with open('Analogue-Nowcasting-Model-Testing-Ground/Saved Models/history_NSCC.pkl', 'rb') as file:
    loaded_history = pickle.load(file)

# Define the encoder model. Find the low dimension layer according to the model summary.
encoder = Model(inputs=autoencoder.input, outputs=autoencoder.get_layer('activation_9').output)

# Generate Encoded Representations for the Database
encoded_database = encoder.predict(data_combined)
encoded_database.shape

# Provide a test image for similarity check
# Load the data for input say
input_data = nc.Dataset('Analogue-Nowcasting-Model-Testing-Ground/ERA5_Data/ERA5_28Nov23Input.nc')

# Extract data
r = np.moveaxis(input_data['r'], 1, 0)
r_input = np.expand_dims(r[0],3)

u_input = np.moveaxis(input_data['u'], 1, -1)
v_input = np.moveaxis(input_data['v'], 1, -1)

# Normalize the data
u_input = scaler.fit_transform(u_input.reshape(-1, 1)).reshape(u_input.shape)
v_input = scaler.fit_transform(v_input.reshape(-1, 1)).reshape(v_input.shape)
r_input = scaler.fit_transform(r_input.reshape(-1, 1)).reshape(r_input.shape)

# Pad the data to get even dimensions
u_input = np.pad(u_input, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
v_input = np.pad(v_input, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
r_input = np.pad(r_input, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')

# Combine the parameters to form a single dataset
input_data_combined = np.concatenate((u_input, v_input, r_input), axis=-1)

# Visualize test image
x, y = np.meshgrid(np.linspace(95, 120, 101), np.linspace(-5, 15, 81))
x = np.linspace(102, 106, 17)
y = np.linspace(3, 0, 13)

# Visualize test image continued
def vector_to_rgb(angle, absolute):
    global max_abs

    # normalize angle
    angle = angle % (2 * np.pi)
    if angle < 0:
        angle += 2 * np.pi

    return matplotlib.colors.hsv_to_rgb((angle / 2 / np.pi, 
                                         absolute / max_abs, 
                                         absolute / max_abs))

# Visualize test image continued
# Plot 925 winds
X = x
Y = y
U_925 = input_data['u'][0][2]
V_925 = input_data['v'][0][2]

angles = np.arctan2(V_925, U_925)
lengths = np.sqrt(np.square(U_925) + np.square(V_925))

max_abs = np.max(lengths)
c = np.array(list(map(vector_to_rgb, angles.flatten(), lengths.flatten())))

plt.quiver(X, Y, U_925, V_925, color=c)
plt.title('28 Nov 2023 925 winds')
plt.savefig('Analogue-Nowcasting-Model-Testing-Ground/Visualisation/28Nov_925.png')
plt.clf()

# Visualize test image continued
# Plot 850 winds
X = x
Y = y
U_850 = input_data['u'][0][1]
V_850 = input_data['v'][0][1]

angles = np.arctan2(V_850, U_850)
lengths = np.sqrt(np.square(U_850) + np.square(V_850))

max_abs = np.max(lengths)
c = np.array(list(map(vector_to_rgb, angles.flatten(), lengths.flatten())))

plt.quiver(X, Y, U_850, V_850, color=c)
plt.title('28 Nov 2023 850 winds')
plt.savefig('Analogue-Nowcasting-Model-Testing-Ground/Visualisation/28Nov_850.png')
plt.clf()

# Visualize test image continued
# Plot 700 winds
X = x
Y = y
U_700 = input_data['u'][0][0]
V_700 = input_data['v'][0][0]

angles = np.arctan2(V_700, U_700)
lengths = np.sqrt(np.square(U_700) + np.square(V_700))

max_abs = np.max(lengths)
c = np.array(list(map(vector_to_rgb, angles.flatten(), lengths.flatten())))

plt.quiver(X, Y, U_700, V_700, color=c)
plt.title('28 Nov 2023 700 winds')
plt.savefig('Analogue-Nowcasting-Model-Testing-Ground/Visualisation/28Nov_700.png')
plt.clf()

# Make sure encoded format of input same with the encoded database
input_day_encoded = encoder.predict(input_data_combined)

# Reshaping to allow calculating of euclidean distances
input_day_encoded_flat = input_day_encoded.reshape(1,-1)
encoded_database_flat = encoded_database.reshape(encoded_database.shape[0], -1)

# Calculate similarities and find the most similar day:
# Use <Euclidean distances> to calculate the Euclidean distances between the input day's encoded representation and the encoded representations of all the days in the database.

from sklearn.metrics.pairwise import euclidean_distances

# Calculate Euclidean distances 
distances = euclidean_distances(input_day_encoded_flat, encoded_database_flat)

# Find the index of the most similar day (smallest distance)
most_similar_day_index = np.argmin(distances)

# Retrieve the data of the most similar day
most_similar_day_data = encoded_database_flat[most_similar_day_index]

# Visualise most similar database image 925 winds
X = x
Y = y
U_925_ms = data['u'][most_similar_day_index][2]
V_925_ms = data['v'][most_similar_day_index][2]

angles = np.arctan2(V_925_ms, U_925_ms)
lengths = np.sqrt(np.square(U_925_ms) + np.square(V_925_ms))

max_abs = np.max(lengths)
c = np.array(list(map(vector_to_rgb, angles.flatten(), lengths.flatten())))

plt.quiver(X, Y, U_925_ms, V_925_ms, color=c)
plt.title('Most similar day 925 winds')
plt.savefig('Analogue-Nowcasting-Model-Testing-Ground/Visualisation/multichannel_most_similar_925.png')
plt.clf()

# Visualise most similar database image 850 winds
X = x
Y = y
U_850_ms = data['u'][most_similar_day_index][1]
V_850_ms = data['v'][most_similar_day_index][1]

angles = np.arctan2(V_850_ms, U_850_ms)
lengths = np.sqrt(np.square(U_850_ms) + np.square(V_850_ms))

max_abs = np.max(lengths)
c = np.array(list(map(vector_to_rgb, angles.flatten(), lengths.flatten())))

plt.quiver(X, Y, U_850_ms, V_850_ms, color=c)
plt.title('Most similar day 850 winds')
plt.savefig('Analogue-Nowcasting-Model-Testing-Ground/Visualisation/multichannel_most_similar_850.png')
plt.clf()

# Visualise most similar database image 700 winds
X = x
Y = y
U_700_ms = data['u'][most_similar_day_index][0]
V_700_ms = data['v'][most_similar_day_index][0]

angles = np.arctan2(V_700_ms, U_700_ms)
lengths = np.sqrt(np.square(U_700_ms) + np.square(V_700_ms))

max_abs = np.max(lengths)
c = np.array(list(map(vector_to_rgb, angles.flatten(), lengths.flatten())))

plt.quiver(X, Y, U_700_ms, V_700_ms, color=c)
plt.title('Most similar day 700 winds')
plt.savefig('Analogue-Nowcasting-Model-Testing-Ground/Visualisation/multichannel_most_similar_700.png')
plt.clf()

# Find the date of most similar day

start_date = dt.datetime(2013, 1, 1)
most_similar_date = start_date + dt.timedelta(days=int(most_similar_day_index))
print(most_similar_date)
