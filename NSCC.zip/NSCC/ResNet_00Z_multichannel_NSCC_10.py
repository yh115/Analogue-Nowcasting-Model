import netCDF4 as nc
import numpy as np
from sklearn.model_selection import train_test_split 
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow.keras.layers import Input, Conv2D, UpSampling2D, Add
from tensorflow.keras.models import Model
import pandas as pd
import pickle

# Define ResNet block
def resnet_block(input_tensor, filters, kernel_size=(2, 2), strides=(1, 1)):
    x = Conv2D(filters, kernel_size, strides=strides, padding='same')(input_tensor)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Activation('relu')(x)
    
    x = Conv2D(filters, kernel_size, padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    
    # Adjust the shortcut connection
    if strides != (1, 1) or input_tensor.shape[-1] != filters:
        shortcut = Conv2D(filters, (1, 1), strides=strides, padding='same')(input_tensor)
    else:
        shortcut = input_tensor
    
    x = Add()([x, shortcut])
    x = tf.keras.layers.Activation('relu')(x)
    return x

# Load the data for three years
data = nc.Dataset('Analogue-Nowcasting-Model-Testing-Ground/ERA5_Data/ERA5_14_to_23_data.nc')

# Shape data
r = np.moveaxis(data['r'], 1, 0)
r = np.expand_dims(r[0],3)
u = np.moveaxis(data['u'], 1, -1)
v = np.moveaxis(data['v'], 1, -1)

# Preprocessing the data
# Normalize the data
scaler = StandardScaler()

u = scaler.fit_transform(u.reshape(-1, 1)).reshape(u.shape)
v = scaler.fit_transform(v.reshape(-1, 1)).reshape(v.shape)
r = scaler.fit_transform(r.reshape(-1, 1)).reshape(r.shape)

# Pad the data to get even dimensions
u = np.pad(u, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
v = np.pad(v, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
r = np.pad(r, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')

# Combine the parameters to form a single dataset
data_combined = np.concatenate((u, v, r), axis=-1)

# Split the data into training and validation sets
X_train_padded, X_val_padded = train_test_split(data_combined, test_size=0.3, shuffle=False)

# Input requires us to provide the shape which is the H X W X C without the number of samples N.
input = Input(shape=X_train_padded[0].shape)

# Encoder
x = resnet_block(input, 64)
x = resnet_block(x, 128)
x = resnet_block(x, 256)
x = resnet_block(x, 512)
encoded = resnet_block(x, 512, strides=(2, 2))

# Decoder
x = UpSampling2D((2, 2))(encoded)
x = resnet_block(x, 512)
x = UpSampling2D((1, 1))(x)
x = resnet_block(x, 256)
x = UpSampling2D((1, 1))(x)
x = resnet_block(x, 128)
x = UpSampling2D((1, 1))(x)
x = resnet_block(x, 64)
decoded = Conv2D(7, (2, 2), activation='sigmoid', padding='same')(x)

# Compile the autoencoder
autoencoder = Model(input, decoded)
autoencoder.compile(optimizer='adam', loss='mse', metrics=['accuracy'])

# inputs are the sample real images of the weather winds and rh patterns, 
# decoded is the supposed same image after going thru the autoencoder-decoder.

# Train the model 
history = autoencoder.fit(X_train_padded, 
                          X_train_padded, 
                          epochs=100, 
                          batch_size=32, 
                          validation_data=(X_val_padded, X_val_padded)
                          )

# Save this model
autoencoder.save('Analogue-Nowcasting-Model-Testing-Ground/Saved Models/ResNet_00Z_Autoencoder_NSCC.keras')

# Save the weights
autoencoder.save_weights('Analogue-Nowcasting-Model-Testing-Ground/Saved Models/ResNet_00Z_Autoencoder_weights_NSCC.h5')

# Save the history object 
# Convert the history.history dict to a pandas DataFrame
hist_df = pd.DataFrame(history.history)

# Save to csv
hist_csv_file = 'Analogue-Nowcasting-Model-Testing-Ground/Saved Models/history_NSCC.csv'
with open(hist_csv_file, mode='w') as f:
    hist_df.to_csv(f)

# Save to pickle
with open('Analogue-Nowcasting-Model-Testing-Ground/Saved Models/history_NSCC.pkl', 'wb') as file:
    pickle.dump(history.history, file)
